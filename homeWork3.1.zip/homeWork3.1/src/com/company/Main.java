package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        double sum = 0.0;
        int count = 0;
        boolean isNegative = false;


        double[] average = {-3, 5, -9, 2, 4, 2, 6};
        for (double number : average) {
            if (number < 0) {
                isNegative = true;
            } else if (isNegative) {
                sum = number;
                count++;
            }
            System.out.println("Среднее арифметическое число: " + sum / count);
        }
    }
}
